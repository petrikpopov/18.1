SELECT * FROM GetInfo('Dating');

select * from GetFields('Dating')

